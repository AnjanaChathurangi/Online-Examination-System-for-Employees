<?php
$servername = "localhost";     
$username = "root";          
$password = "";             
$dbname = "blue_kite";      

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    echo"Connection Failed: ";
}
else{
    
}
?>
