<!DOCTYPE html>
<html>
<head>
  
</head>
<body>
  <?php include 'navbar.php';?>
 


 Chalanage tika add krnnooooo mekataaaaaaaaa. <br>folders athule thiyena ewatth wenama dannaaaaaaaa


  <?php include 'footer.php';?>
</body>


</html>

