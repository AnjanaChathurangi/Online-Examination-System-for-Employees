<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" type="text/css" href="edit.css" /> 
</head>

<body>
<?php include 'navbar.php';?>
    <div class="main">
        <div class="upper">

         <div class="box"><div class="text"><a href="#">Get Exam Report</a></div></div>
         <div class="box"><div class="text"><a href="#">Manage FAQ</a></div></div>
         <div class="box"><div class="text"><a href="#">Manage Exam</a></div></div>
         
    </div>
        </div>
        <div class="top">
            <div class="up">
                <input type="button" value="Manage Users">
                <input type="search" ><br><br>

            </div>
            <div class="middle">
                <div class="card">
                <li>EM180050</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>
            

            
                <div class="card">
                <li>EM190040</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>
            

            
                <div class="card">
                <li>EM200450</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>

                <div class="card">
                <li>EM220010</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>
</div>
<div class="main">
        <div class="top">
            <div class="up">
                <input type="button" value="Exam Panel">
                <input type="search"><br><br>
            </div>

                <br><br>
                <div class="middle">
                <div class="card">
                <li>EP180055</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>

                <div class="card">
                <li>EP190011</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>

                <div class="card">
                <li>EP190233</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>

                <div class="card">
                <li>EP190233</li>
                <img src="image/profile.png" width="80px">
                <input type="button" value="Edit User">
                </div>

                


                


                </div>
            </div>
        </div>


    </div>



    <?php include 'footer.php';?>
</body>
</html>