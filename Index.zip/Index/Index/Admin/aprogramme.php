<!DOCTYPE html>
<html>
<head>
  
</head>
<body>
  <?php include 'navbar.php';?>
 


  <link rel="stylesheet" type="text/css" href="programe.css">



<section class="container">
  <div class="card">
      <div class="card-image"></div>
      <div class="FRVbox"><h2>FAQ</h2><br>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente consequatur tempore eligendi totam eveniet aperiam, esse ab reiciendis neque eum deleniti asperiores ut odit officia fugit! Optio temporibus tenetur sequi!</p>  
    </div>
      
      <div class="box"><a href="faq.php">View more</a></div>
  </div>
  <div class="card">
      <div class="card-image"></div>
      <div class="FRVbox"><h2>View Reults</h2><br>
      <p>Lorem ipsum, dolor sit amet consectetur adipi iste rerum inventore eligendi incidunt.</p> </div>
       <div class="box"><a href="viewResult.php">View more</a></div>
  </div>
  <div class="card">
      <div class="card-image"></div>
      <div class="FRVbox"><h2>Enroll to Exam</h2><br>
      <p>Lorem ipsum, dolor sit amet consectetur adipi iste rerum inventore eligendi incidunt.</p> </div>
      <div class="box"><a href="EnrollExam.php">View more</a></div>
  </div>
</section>


  <?php include 'footer.php';?>
</body>


</html>


