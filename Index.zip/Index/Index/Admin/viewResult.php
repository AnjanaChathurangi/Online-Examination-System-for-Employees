<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="viewresults.css">
</head>
<body>

<?php include 'navbar.php';?>
<div class="attemtExam">
  <div class="BK101"><p>BK101</p> <br>
      <a href="">View Result</a>
  </div>
  <div class="BK101"><p>BK102</p> <br>
      <a href="">View Result</a>

  </div><div class="BK101"><p>BK301</p> <br>
      <a href="">View Result</a>
  </div>
 
</div>

  <?php include 'footer.php';?>
</body>


</html>
