
  
  
  
  
  
  <link rel="stylesheet" type="text/css" href="Enrollcss.css">

  <?php include 'navbar.php';?>
<div class="attemtExam">
    <div class="BK101"><p>BK101</p> <br>
        <a href="">Attempt Exam</a>
    </div>
    <div class="BK101"><p>BK102</p> <br>
        <a href="">Attempt Exam</a>
    </div><div class="BK101"><p>BK301</p> <br>
        <a href="">Attempt Exam</a>
    </div>
    <?php include 'footer.php';?>
</div>

  
