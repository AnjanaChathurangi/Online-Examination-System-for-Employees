<!DOCTYPE html>
<html>
  <head> 
  <div class="div">
    <link rel="stylesheet" type="text/css" href="notice.css" />
  </div>
  </head>
  <body>
    <?php include 'navbar.php';?>
    <div class="div">
    <div class="mainf">
      <div class="card">
        <div class="top"><div class="top-text">Attention !</div></div>
        <div class="mid">
          <div class="mid-text">
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem minus
          dolore, deleniti eum obcaecati esse sint nihil, aliquid consequatur
          recusandae quaerat provident, voluptatem expedita eveniet. Magnam qui
          aut ea mias.
          </div>
        </div>
      </div>

      <div class="mainf">
        <div class="card">
          <div class="top"><div class="top-text">Employee Notice</div></div>
          <div class="mid">
            <div class="mid-text">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem minus
            dolore, deleniti eum obcaecati esse sint nihil, aliquid consequatur
            recusandae quaerat provident, voluptatem expedita eveniet. Masint nihil, aliquid consequatur
            
            </div>
          </div>
        </div>

        <div class="mainf">
          <div class="card">
            <div class="top"><div class="top-text">Exam Notice</div></div>
            <div class="mid">
              <div class="mid-text">
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem minus
              dolore, deleniti eum obcaecati esse sint nihil, aliquid consequatur
              recusandae quaerat provident, voluptatem expedita eveniet. Magnam qui
              aut ea mias.
              </div>
            </div>
          </div>

          <div class="mainf">
            <div class="card">
              <div class="top"><div class="top-text">Exam Results</div></div>
              <div class="mid">
                <div class="mid-text">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem minus
                dolore, deleniti eum obcaecati esse sint nihil, aliquid consequatur
                recusandae quaerat provident, voluptatem expedita eveniet. Magnam qui
                aut ea mias.
                </div>
              </div>
            </div>

            <div class="mainf">
              <div class="card">
                <div class="top"><div class="top-text">Administrator Pannel</div></div>
                <div class="mid">
                  <div class="mid-text">
                  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem minus
                  dolore, deleniti eum obcaecati esse sint nihil, aliquid consequatur
                  recusandae quaerat provident, voluptatem expedita eveniet. Magnam qui
                  aut ea mias.
                  </div>
                </div>
              </div>
              </div>

              <div class="mainf">
              <div class="card">
                <div class="top"><div class="top-text">Administrator Pannel</div></div>
                <div class="mid">
                  <div class="mid-text">
                  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem minus
                  dolore, deleniti eum obcaecati esse sint nihil, aliquid consequatur
                  recusandae quaerat provident, voluptatem expedita eveniet. Magnam qui
                  aut ea mias.
                  </div>
                </div>
              </div>
              </div>
  
  <div class="div">
    <?php include 'footer.php';?>
    </div>
  </body>
</html>
