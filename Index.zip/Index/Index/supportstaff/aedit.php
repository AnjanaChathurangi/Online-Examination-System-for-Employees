<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="ManageFaq.css">
    
</head>
<body>
  <?php include 'navbar.php';?>
  <div class="container-3">
         <div class="box"><div class="text"><a href="">Manage FAQ</a></div></div>
         <div class="box"><div class="text"><a href="mailto:bluekite278@gmail.com">Check Mails</a>
         </div></div>
    </div>
<div class="full">
<div class="container-QA">
  
    <div class="QA">
        <div class="queAns">
           <div class="QAbox">
                <div class="checkboxstyle">
                    <label>
                        <input type="checkbox">
                    </label>
                </div>
              <div class="Question">Lorem ipsum dolor sit amet consectetur, adipisicing elit.</div> 
              <div class="Answers">Quis pariatur, odit ducimus </div> 
            </div>
        </div>
    </div>

    <div class="QA">
        <div class="queAns">
           <div class="QAbox">
                <div class="checkboxstyle">
                    <label>
                        <input type="checkbox">
                    </label>
                </div>
              <div class="Question">Lorem ipsum dolor sit amet consectetur, adipisicing elit.</div> 
              <div class="Answers">Quis pariatur, odit ducimus </div> 
            </div>
        </div>
    </div>

    <div class="QA">
        <div class="queAns">
           <div class="QAbox">
                <div class="checkboxstyle">
                    <label>
                        <input type="checkbox">
                    </label>
                </div>
              <div class="Question">Lorem ipsum dolor sit amet consectetur, adipisicing elit.</div> 
              <div class="Answers">Quis pariatur, odit ducimus </div> 
            </div>
        </div>
    </div>

    <div class="QA">
        <div class="queAns">
           <div class="QAbox">
                <div class="checkboxstyle">
                    <label>
                        <input type="checkbox">
                    </label>
                </div>
              <div class="Question">Lorem ipsum dolor sit amet consectetur, adipisicing elit.</div> 
              <div class="Answers">Quis pariatur, odit ducimus </div> 
            </div>
        </div>
    </div>

    <div class="QA">
        <div class="queAns">
           <div class="QAbox">
                <div class="checkboxstyle">
                    <label>
                        <input type="checkbox">
                    </label>
                </div>
              <div class="Question">Lorem ipsum dolor sit amet consectetur, adipisicing elit.</div> 
              <div class="Answers">Quis pariatur, odit ducimus </div> 
            </div>
        </div>
    </div>
    
</div>

<div class="addQA">
    <li class="topic">Add more</li>

    <li class="sub-topic">Question</li>
    <input type="text">
    <li class="sub-topic">Answer</li>
    <input type="text">

</div>
</div>
  <?php include 'footer.php';?>
</body>


</html>