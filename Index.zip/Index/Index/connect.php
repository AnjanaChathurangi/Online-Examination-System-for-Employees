<?php
$servername = "localhost";     // Replace with your server name
$username = "root";          // Replace with your username
$password = "";             // Replace with your password
$dbname = "blue_kite";      // Replace with your database name

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


// Check connection
if (!$conn) {
    echo"Connection Failed: ";
}
else{
    
}
?>
