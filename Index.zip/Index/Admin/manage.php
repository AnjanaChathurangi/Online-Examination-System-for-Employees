<!DOCTYPE html>
<html>
<head>
  
</head>
<body>
  <?php include 'navbar.php';?>
 


  enter the details here


  <?php include 'footer.php';?>
</body>


</html>
