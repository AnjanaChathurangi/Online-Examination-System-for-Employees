
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="footer.css">
        


    </head>

<body>

       
    <div class="footer">
      <div class="contain">
      <div class="col">
        <h1>Feature</h1>
        <ul>
          <li>About</li>
          <li>Mission</li>
          
        </ul>
      </div>
      <div class="col">
        <h1>Account</h1>
        <ul>
          <li>Sign In</li>
          <li>Log In</li>
          
        </ul>
      </div>
      <div class="col">
        <h1>Support</h1>
        <ul>
          <li>FAQ</li>
          <li>Contact Us</li>
          
        </ul>
      </div>
      <div class="col">
        <h1>Privacy & policy</h1>
        <ul>
          <li>Webmail</li>
          <li>Privacy</li>
          
        </ul>
      </div>
      <div class="col">
        <h1>Bluekite</h1>
        <ul>
          <li>Members</li>
          <li>Examination</li>
          <li>Notices</li>
          
        </ul>
      </div>
      <div class="col social">
        <h1>Social</h1>
        <ul>
        <li><a href="https://www.facebook.com/Bluekite-103616439433839/"><img src="../Images/facebook.png" width="32" style="width: 32px;"></a></li>
        <li><a href="https://www.instagram.com/"><img src="../Images/instagram.png" width="32" style="width: 32px;"></a></li>
        <li><a href="https://github.com/bluekiteus"><img src="../Images/github.png" width="32" style="width: 32px;"></a></li>
                
        </ul>
      </div>
    <div class="clearfix"></div>
    </div>
    </div>
    
</body>


</html>
